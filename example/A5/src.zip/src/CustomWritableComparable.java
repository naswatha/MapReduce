/**
 * @classname: CustomWritableComparable
 * 
 * @author Hu,Ruinan Aswathanarayana,Naveen	
 * @description This is used to implement the sort for the CustomWritable objects.
 *
 */


public class CustomWritableComparable implements Comparable<CustomWritableComparable>{
	public String cityName;
	public int flightType;
	public long flightTime;
	public long actualTime;
	public int fT;
	public int aT;
	public String date;
	public  CustomWritableComparable(){

	}
	/*public CustomWritableComparable(Text cityName, int flightType, long flightTime, long actualTime, int fT, int aT, Text date) {
		this.cityName = cityName;
		this.flightType = flightType;
		this.flightTime = flightTime;
		this.actualTime = actualTime;
		this.fT = fT;
		this.aT = aT;
		this.date = date;
	}*/
	
	public CustomWritableComparable(String value) {
		String[] values = value.split(",");
		this.cityName = values[0];
		this.flightType = Integer.parseInt(values[1]);
		this.flightTime = Long.parseLong(values[2]);
		this.actualTime = Long.parseLong(values[3]);
		this.fT = Integer.parseInt(values[4]);
		this.aT = Integer.parseInt(values[5]);
		this.date = values[6];
	}
	
	@Override
	public int compareTo(CustomWritableComparable comparesTTS) {
		long flightTime=comparesTTS.flightTime;
		//For Ascending order /1000 or too large for int 31536000 secs in a year
		return (int)(this.flightTime-flightTime);
	}
	@Override
	public String toString() {
	return "Test";
	}

}
